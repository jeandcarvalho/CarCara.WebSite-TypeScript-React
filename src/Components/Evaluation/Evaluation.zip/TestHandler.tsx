// src/Components/TestHandler.tsx
import { useEffect, useState } from "react";
import {
  useNavigate,
  useParams,
  useSearchParams,
} from "react-router-dom";
import Header from "../Header";
import Footer from "../Footer";
import loadgif from "../img/gif.gif";

import { LLMTestDetailPanel } from "./LLMTestDetailPanel";
import { LLMTestEvaluationPanel } from "./LLMTestEvaluationPanel";
import { LLMTestDocumentsPanel } from "./LLMTestDocumentsPanel";

const API_BASE = "https://carcara-web-api.onrender.com";

export type LLMResultDoc = {
  id: string;
  acq_id: string;
  sec: number;
  testName: string;
  llmModel: string;
  promptType: string;
  prompt?: string | null;
  response?: string | null;
  promptTokens?: number | null;
  completionTokens?: number | null;
  totalTokens?: number | null;
  latencyMs?: number | null;
  createdAt: string;
};

type LLMResultDocsResponse = {
  items: LLMResultDoc[];
  total: number;
  page: number;
  pageSize: number;
  testName?: string | null;
  llmModel?: string | null;
  promptType?: string | null;
  prompt?: string | null;
};

export type LLMTestEval = {
  id?: string;
  collectionId: string;
  acq_id: string;
  sec: number;
  test1: number;
  test2: number;
  test3: number;
  test4: number;
  test5: number;
};

export type EvalMap = Record<string, LLMTestEval>;

const makeKey = (acq_id: string, sec: number) => `${acq_id}__${sec}`;

const TestHandler: React.FC = () => {
  const { collectionId } = useParams<{ collectionId: string }>();
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();

  const token =
    typeof window !== "undefined"
      ? localStorage.getItem("token")
      : null;
  const isAuthenticated = !!token;

  const [errorMsg, setErrorMsg] = useState("");
  const [globalLoading, setGlobalLoading] = useState(true);

  const [docsResp, setDocsResp] = useState<LLMResultDocsResponse | null>(
    null
  );
  const [docsLoading, setDocsLoading] = useState(false);

  const [page, setPage] = useState<number>(() => {
    const p = Number(searchParams.get("page") ?? "1");
    return Number.isFinite(p) && p > 0 ? p : 1;
  });
  const pageSize = 20;

  const [selectedDoc, setSelectedDoc] = useState<LLMResultDoc | null>(
    null
  );

  const [evalsByKey, setEvalsByKey] = useState<EvalMap>({});
  const [evalsLoading, setEvalsLoading] = useState(false);
  const [savingEval, setSavingEval] = useState(false);

  const [currentEval, setCurrentEval] = useState<{
    test1: number;
    test2: number;
    test3: number;
    test4: number;
    test5: number;
  } | null>(null);

  const testNameParam = searchParams.get("testName") ?? "";
  const llmModelParam = searchParams.get("llmModel") ?? "";
  const promptTypeParam = searchParams.get("promptType") ?? "";

  const effectiveTestName = docsResp?.testName ?? testNameParam;
  const effectiveLlmModel = docsResp?.llmModel ?? llmModelParam;
  const effectivePromptType =
    docsResp?.promptType ?? promptTypeParam;
  const effectivePrompt = docsResp?.prompt ?? null;

  // 1) carrega docs do teste (LLMResult)
  useEffect(() => {
    if (!collectionId) {
      setErrorMsg("Collection id missing.");
      setGlobalLoading(false);
      return;
    }

    if (!testNameParam) {
      setErrorMsg("Missing testName in URL.");
      setGlobalLoading(false);
      return;
    }

    const loadDocs = async () => {
      try {
        setDocsLoading(true);
        setErrorMsg("");

        const params = new URLSearchParams({
          testName: testNameParam,
          promptType: promptTypeParam,
          llmModel: llmModelParam,
          page: String(page),
          pageSize: String(pageSize),
        });

        const url = `${API_BASE}/api/llm/test-docs/${collectionId}?${params.toString()}`;

        console.log("[TestHandler] fetching:", url);

        const headers: HeadersInit = {};
        if (token) {
          headers["Authorization"] = `Bearer ${token}`;
        }

        const res = await fetch(url, { headers });

        const data = await res.json().catch(() => null);

        console.log("[TestHandler] raw response status:", res.status);
        console.log("[TestHandler] raw response body:", data);

        if (!res.ok) {
          setErrorMsg(
            (data && (data.error || data.message)) ||
              "Error loading LLM test docs."
          );
          setDocsResp(null);
          setGlobalLoading(false);
          return;
        }

        let items: any[] = [];
        let total = 0;
        let pageNum = page;
        let pageSizeNum = pageSize;

        if (data && Array.isArray(data.items)) {
          items = data.items;
          total = data.total ?? items.length;
          pageNum = data.page ?? page;
          pageSizeNum = data.pageSize ?? pageSize;
        } else if (data && Array.isArray(data.data)) {
          items = data.data;
          total = items.length;
          pageNum = 1;
          pageSizeNum = items.length || 1;
        } else if (Array.isArray(data)) {
          items = data;
          total = items.length;
          pageNum = 1;
          pageSizeNum = items.length || 1;
        } else {
          console.warn("[TestHandler] unexpected shape:", data);
          setDocsResp(null);
          setGlobalLoading(false);
          return;
        }

        console.log("[TestHandler] items array:", items);

        const metaTestName: string =
          data?.testName ?? data?.test_name ?? testNameParam;

        const metaLlmModel: string =
          data?.llmModel ?? data?.llm_model ?? llmModelParam;

        const metaPromptType: string =
          data?.promptType ?? data?.prompt_type ?? promptTypeParam;

        const metaPrompt: string | null =
          data?.prompt ?? data?.prompt_text ?? null;

        let mappedItems: LLMResultDoc[] = items.map((d: any) => ({
          id:
            d.id ??
            d._id ??
            `${d.acq_id}-${d.sec ?? d.center_sec ?? 0}`,
          acq_id: d.acq_id,
          sec: d.sec ?? d.center_sec ?? 0,
          testName: d.testName ?? d.test_name ?? metaTestName,
          llmModel: d.llmModel ?? d.llm_model ?? metaLlmModel,
          promptType:
            d.promptType ?? d.prompt_type ?? metaPromptType,
          prompt: d.prompt ?? d.prompt_text ?? metaPrompt,
          response: d.response ?? d.answer ?? null,
          promptTokens: d.promptTokens ?? d.prompt_tokens ?? null,
          completionTokens:
            d.completionTokens ?? d.completion_tokens ?? null,
          totalTokens: d.totalTokens ?? d.total_tokens ?? null,
          latencyMs:
            d.latencyMs ??
            (d.response_time_s != null
              ? Math.round(d.response_time_s * 1000)
              : null),
          createdAt:
            typeof d.createdAt === "string"
              ? d.createdAt
              : d.createdAt
              ? new Date(d.createdAt).toISOString()
              : new Date().toISOString(),
        }));

        // ordena por acq_id e depois por sec
        mappedItems = mappedItems.sort((a, b) => {
          const acqCmp = a.acq_id.localeCompare(b.acq_id);
          if (acqCmp !== 0) return acqCmp;
          return a.sec - b.sec;
        });

        console.log("[TestHandler] mapped items:", mappedItems);

        setDocsResp({
          items: mappedItems,
          total,
          page: pageNum,
          pageSize: pageSizeNum,
          testName: metaTestName,
          llmModel: metaLlmModel,
          promptType: metaPromptType,
          prompt: metaPrompt,
        });

        // auto-seleciona o primeiro doc
        if (!selectedDoc && mappedItems.length > 0) {
          setSelectedDoc(mappedItems[0]);
        }

        setGlobalLoading(false);
      } catch (err) {
        console.error("[TestHandler] fetch error:", err);
        setErrorMsg("Connection error while loading docs.");
        setDocsResp(null);
        setGlobalLoading(false);
      } finally {
        setDocsLoading(false);
      }
    };

    setGlobalLoading(true);
    loadDocs();
  }, [
    token,
    collectionId,
    testNameParam,
    llmModelParam,
    promptTypeParam,
    page,
    selectedDoc,
  ]);

  // 2) carrega avaliações se autenticado
  useEffect(() => {
    if (
      !isAuthenticated ||
      !collectionId ||
      !effectiveTestName ||
      !effectiveLlmModel ||
      !effectivePromptType
    ) {
      setEvalsByKey({});
      return;
    }

    const loadEvals = async () => {
      try {
        setEvalsLoading(true);
        const params = new URLSearchParams({
          collectionId,
          testName: effectiveTestName,
          llmModel: effectiveLlmModel,
          promptType: effectivePromptType,
        });

        const url = `${API_BASE}/api/llm/eval?${params.toString()}`;

        console.log("[TestHandler] fetching evals:", url);

        const res = await fetch(url, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        const data = await res.json().catch(() => null);
        console.log("[TestHandler] evals raw:", data);

        if (!res.ok) {
          console.warn(
            "[TestHandler] error loading evals:",
            data?.error || data
          );
          return;
        }

        let items: any[] = [];
        if (Array.isArray(data)) {
          items = data;
        } else if (data && Array.isArray(data.items)) {
          items = data.items;
        } else if (data && Array.isArray(data.data)) {
          items = data.data;
        }

        const mapped: EvalMap = {};
        items.forEach((e: any) => {
          if (!e.acq_id || e.sec == null) return;
          const key = makeKey(String(e.acq_id), Number(e.sec));
          mapped[key] = {
            id: e.id ?? e._id,
            collectionId: String(e.collectionId ?? collectionId),
            acq_id: String(e.acq_id),
            sec: Number(e.sec),
            test1: Number(e.test1 ?? 0),
            test2: Number(e.test2 ?? 0),
            test3: Number(e.test3 ?? 0),
            test4: Number(e.test4 ?? 0),
            test5: Number(e.test5 ?? 0),
          };
        });

        setEvalsByKey(mapped);
      } catch (err) {
        console.error("[TestHandler] error loading evals:", err);
      } finally {
        setEvalsLoading(false);
      }
    };

    loadEvals();
  }, [
    isAuthenticated,
    token,
    collectionId,
    effectiveTestName,
    effectiveLlmModel,
    effectivePromptType,
  ]);

  // 3) atualiza currentEval quando muda doc ou evals
  useEffect(() => {
    if (!isAuthenticated || !selectedDoc) {
      setCurrentEval(null);
      return;
    }

    const key = makeKey(selectedDoc.acq_id, selectedDoc.sec);
    const existing = evalsByKey[key];

    if (existing) {
      setCurrentEval({
        test1: existing.test1,
        test2: existing.test2,
        test3: existing.test3,
        test4: existing.test4,
        test5: existing.test5,
      });
    } else {
      setCurrentEval({
        test1: 0,
        test2: 0,
        test3: 0,
        test4: 0,
        test5: 0,
      });
    }
  }, [isAuthenticated, selectedDoc, evalsByKey]);

  const totalPages =
    docsResp && docsResp.pageSize > 0
      ? Math.max(1, Math.ceil(docsResp.total / docsResp.pageSize))
      : 1;

  const handleBackToTests = () => {
    if (!collectionId) return;
    navigate(`/collections/${collectionId}/llm-tests`);
  };

  const handleChangePage = (newPage: number) => {
    setPage(newPage);
    const newParams = new URLSearchParams(searchParams);
    newParams.set("page", String(newPage));
    setSearchParams(newParams);
  };

  const getRowEvalStatus = (doc: LLMResultDoc) => {
    if (!isAuthenticated) return "none" as const;
    const key = makeKey(doc.acq_id, doc.sec);
    const ev = evalsByKey[key];
    if (!ev) return "none" as const;
    const vals = [ev.test1, ev.test2, ev.test3, ev.test4, ev.test5];
    const positiveCount = vals.filter((v) => v > 0).length;
    if (positiveCount === 0) return "none" as const;
    if (positiveCount === vals.length) return "full" as const;
    return "partial" as const;
  };

  const handleSetScore = (
    field: "test1" | "test2" | "test3" | "test4" | "test5",
    value: number
  ) => {
    if (!isAuthenticated || !currentEval) return;
    const clamped = Math.max(1, Math.min(5, value)); // 1..5
    setCurrentEval((prev) => {
      if (!prev) return prev;
      const currentVal = prev[field] as number;
      const newVal = currentVal === clamped ? 0 : clamped; // desmarca se clicar de novo
      return {
        ...prev,
        [field]: newVal,
      };
    });
  };

  const handleSaveEval = async () => {
    if (
      !isAuthenticated ||
      !token ||
      !collectionId ||
      !selectedDoc ||
      !currentEval ||
      !effectiveTestName ||
      !effectiveLlmModel ||
      !effectivePromptType
    ) {
      return;
    }

    try {
      setSavingEval(true);
      setErrorMsg("");

      const body = {
        collectionId,
        acq_id: selectedDoc.acq_id,
        sec: selectedDoc.sec,
        testName: effectiveTestName,
        llmModel: effectiveLlmModel,
        promptType: effectivePromptType,
        test1: currentEval.test1,
        test2: currentEval.test2,
        test3: currentEval.test3,
        test4: currentEval.test4,
        test5: currentEval.test5,
      };

      const res = await fetch(`${API_BASE}/api/llm/eval`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(body),
      });

      const data = await res.json().catch(() => null);
      console.log("[TestHandler] save eval result:", data);

      if (!res.ok) {
        setErrorMsg(
          data?.error ||
            data?.message ||
            "Error saving evaluation."
        );
        return;
      }

      const key = makeKey(selectedDoc.acq_id, selectedDoc.sec);
      setEvalsByKey((prev) => ({
        ...prev,
        [key]: {
          id: data?.id ?? data?._id ?? prev[key]?.id,
          collectionId,
          acq_id: selectedDoc.acq_id,
          sec: selectedDoc.sec,
          test1: currentEval.test1,
          test2: currentEval.test2,
          test3: currentEval.test3,
          test4: currentEval.test4,
          test5: currentEval.test5,
        },
      }));
    } catch (err) {
      console.error("[TestHandler] error saving eval:", err);
      setErrorMsg("Connection error while saving evaluation.");
    } finally {
      setSavingEval(false);
    }
  };

  const handlePrevNext = (direction: "prev" | "next") => {
    if (!docsResp || !selectedDoc) return;
    const items = docsResp.items;
    const idx = items.findIndex(
      (d) =>
        d.id === selectedDoc.id ||
        (d.acq_id === selectedDoc.acq_id && d.sec === selectedDoc.sec)
    );
    if (idx === -1) return;
    const newIdx = direction === "prev" ? idx - 1 : idx + 1;
    if (newIdx < 0 || newIdx >= items.length) return;
    setSelectedDoc(items[newIdx]);
  };

  return (
    <div className="bg-zinc-950 min-h-screen flex flex-col">
      <Header />

      <div className="flex-grow flex justify-center px-4">
        <main className="w-full max-w-6xl py-4">
          <div className="flex items-center justify-between mb-4 gap-2">
            <h1 className="text-3xl font-medium text-yellow-300">
              LLM Test Handler
            </h1>

            {isAuthenticated && (
              <button
                onClick={handleBackToTests}
                className="bg-zinc-800 hover:bg-zinc-700 text-gray-100 text-sm font-semibold py-2 px-4 rounded-lg"
              >
                Back to tests
              </button>
            )}
          </div>

          {collectionId && (
            <p className="text-gray-300 mb-2 text-sm">
              <span className="font-semibold text-yellow-200">
                Collection ID:
              </span>{" "}
              {collectionId}
            </p>
          )}

          <div className="mb-3 text-sm text-gray-300">
            <p>
              <span className="font-semibold text-yellow-100">
                Test:
              </span>{" "}
              {effectiveTestName || "(unknown)"}
            </p>
            <p>
              <span className="font-semibold text-yellow-100">
                Model:
              </span>{" "}
              {effectiveLlmModel || "(unknown)"}
            </p>
            <p>
              <span className="font-semibold text-yellow-100">
                Prompt type:
              </span>{" "}
              {effectivePromptType || "(unknown)"}
            </p>
            {effectivePrompt && (
              <p className="text-xs text-gray-400 mt-2">
                <span className="font-semibold text-yellow-200">
                  Prompt preview:
                </span>{" "}
                {effectivePrompt.length > 220
                  ? `${effectivePrompt.slice(0, 220)}…`
                  : effectivePrompt}
              </p>
            )}
          </div>

          {errorMsg && (
            <div className="bg-red-900 text-red-100 p-2 rounded mb-4">
              {errorMsg}
            </div>
          )}

          {globalLoading ? (
            <div className="flex flex-col items-center justify-center py-10">
              <img
                src={loadgif}
                alt="Loading..."
                className="w-24 h-24 mb-3"
              />
              <p className="text-gray-200 text-sm">
                Loading documents...
              </p>
            </div>
          ) : !docsResp || docsResp.items.length === 0 ? (
            <p className="text-gray-300 text-sm">
              No documents for this test (or unable to load them).
            </p>
          ) : (
            <>
              {isAuthenticated ? (
                // ===================== MODO LOGADO =====================
                <div className="flex flex-col gap-4 lg:grid lg:grid-cols-2 lg:gap-4">
                  {/* DETAIL PANEL - topo full width */}
                  <section className="bg-zinc-900 border border-zinc-800 rounded p-4 order-1 lg:order-1 lg:col-span-2">
                    <LLMTestDetailPanel
                      selectedDoc={selectedDoc}
                      onPrev={() => handlePrevNext("prev")}
                      onNext={() => handlePrevNext("next")}
                      showMetrics={false}
                    />
                  </section>

                  {/* EVALUATION PANEL */}
                  <section className="bg-zinc-900 border border-zinc-800 rounded p-4 order-2 lg:order-3">
                    <LLMTestEvaluationPanel
                      selectedDoc={selectedDoc}
                      currentEval={currentEval}
                      evalsLoading={evalsLoading}
                      savingEval={savingEval}
                      onSetScore={handleSetScore}
                      onSave={handleSaveEval}
                    />
                  </section>

                  {/* DOCUMENTS PANEL */}
                  <section className="bg-zinc-900 border border-zinc-800 rounded p-4 order-3 lg:order-2">
                    <LLMTestDocumentsPanel
                      docsResp={docsResp}
                      docsLoading={docsLoading}
                      selectedDoc={selectedDoc}
                      onSelectDoc={setSelectedDoc}
                      page={page}
                      totalPages={totalPages}
                      onChangePage={handleChangePage}
                      isAuthenticated={true}
                      getRowEvalStatus={getRowEvalStatus}
                    />
                  </section>
                </div>
              ) : (
                // ===================== MODO PÚBLICO (SEM LOGIN) =====================
                <div className="flex flex-col gap-4">
                  {/* DETAIL EM CIMA (FULL) */}
                  <section className="bg-zinc-900 border border-zinc-800 rounded p-4">
                    <LLMTestDetailPanel
                      selectedDoc={selectedDoc}
                      onPrev={() => handlePrevNext("prev")}
                      onNext={() => handlePrevNext("next")}
                      showMetrics={true}
                    />
                  </section>

                  {/* DOCUMENTS EMBAIXO (FULL) */}
                  <section className="bg-zinc-900 border border-zinc-800 rounded p-4">
                    <LLMTestDocumentsPanel
                      docsResp={docsResp}
                      docsLoading={docsLoading}
                      selectedDoc={selectedDoc}
                      onSelectDoc={setSelectedDoc}
                      page={page}
                      totalPages={totalPages}
                      onChangePage={handleChangePage}
                      isAuthenticated={false}
                    />
                  </section>
                </div>
              )}
            </>
          )}
        </main>
      </div>

      <Footer />
    </div>
  );
};

export default TestHandler;
