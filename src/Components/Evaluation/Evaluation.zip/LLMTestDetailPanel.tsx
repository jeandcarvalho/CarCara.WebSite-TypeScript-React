// src/Components/LLMTestDetailPanel.tsx
import React from "react";
import type { LLMResultDoc } from "./TestHandler";

type Props = {
  selectedDoc: LLMResultDoc | null;
  onPrev: () => void;
  onNext: () => void;
  showMetrics?: boolean; // true no modo público
};

const formatDateTime = (iso?: string | null) => {
  if (!iso) return "-";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "-";
  return d.toLocaleString();
};

export const LLMTestDetailPanel: React.FC<Props> = ({
  selectedDoc,
  onPrev,
  onNext,
  showMetrics = false,
}) => {
  return (
    <>
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-xl text-yellow-200">Detail</h2>

        <div className="flex gap-3 text-sm">
          <button
            onClick={onPrev}
            className="py-2 px-4 rounded-lg border border-zinc-700 text-gray-100 hover:bg-zinc-800 font-medium"
          >
            ← Prev
          </button>
          <button
            onClick={onNext}
            className="py-2 px-4 rounded-lg border border-zinc-700 text-gray-100 hover:bg-zinc-800 font-medium"
          >
            Next →
          </button>
        </div>
      </div>

      {!selectedDoc ? (
        <p className="text-sm text-gray-300">
          Select a document to view details.
        </p>
      ) : (
        <div className="space-y-3 text-sm">
          <div>
            <p className="text-[11px] text-gray-400 mb-1">
              Prompt (raw)
            </p>
            <div className="bg-zinc-800 border border-zinc-700 rounded p-3 whitespace-pre-wrap text-gray-100 text-[12px] max-h-48 overflow-y-auto">
              {selectedDoc.prompt || "(no prompt saved)"}
            </div>
          </div>

          <div>
            <p className="text-[11px] text-gray-400 mb-1">Response</p>
            <div className="bg-zinc-800 border border-zinc-700 rounded p-3 whitespace-pre-wrap text-gray-100 text-[12px] max-h-48 overflow-y-auto">
              {selectedDoc.response || "(no response saved)"}
            </div>
          </div>

          {showMetrics && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-[11px] text-gray-300">
              <div>
                <span className="font-semibold text-yellow-200">
                  latency:
                </span>{" "}
                {selectedDoc.latencyMs != null
                  ? `${selectedDoc.latencyMs} ms`
                  : "-"}
              </div>
              <div>
                <span className="font-semibold text-yellow-200">
                  tokens:
                </span>{" "}
                {selectedDoc.totalTokens ?? "-"}
              </div>
              <div className="col-span-2">
                <span className="font-semibold text-yellow-200">
                  created at:
                </span>{" "}
                {formatDateTime(selectedDoc.createdAt)}
              </div>
            </div>
          )}
        </div>
      )}
    </>
  );
};
